# MBLP131 — Hafta 15: Final Sınavı Tekrarı ve Alıştırma

**Kod paketi** · MBLP131 — İşletim Sistemleri Temelleri  
Dr. Öğr. Üyesi Hasan Oğuz

## İçindekiler

| Dosya | Açıklama (dosyanın başındaki yorumdan) |
|---|---|
| `mcmp117_lab_setup.sh` | ~/lab alıştırma klasörünü oluşturur (bir kez çalıştırın: `bash mcmp117_lab_setup.sh`) |
| `answers_practice.sh` | verifies every command/pipeline/script answer of the Practice Final in the Week 15 study guide (Parts D, E, F). |
| `count_lines.sh` | print the number of lines of every regular file in a directory |
| `demo_lib.sh` | tiny helpers sourced by the Week 15 demo/answer scripts. |
| `demo_recap.sh` | the practical recap of Weeks 9-14 (slides + study guide). |
| `demo_worked.sh` | worked practical problems 5-7 of the Week 15 slides. |
| `dept_stats.sh` | number of students and average final grade of ONE department |
| `passfail.sh` | how many students reached a given final-exam grade |
| `out_pf_d1.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (pf_d1); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_pf_d2.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (pf_d2); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_pf_d3.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (pf_d3); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_pf_d4.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (pf_d4); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_pf_d5.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (pf_d5); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_pf_d6.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (pf_d6); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_pf_d7.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (pf_d7); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_pf_e1.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (pf_e1); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_pf_e2.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (pf_e2); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_pf_e3.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (pf_e3); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_pf_f_run.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (pf_f_run); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_pf_f_src.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (pf_f_src); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_w09.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (w09); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_w10.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (w10); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_w11.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (w11); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_w12.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (w12); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_w13.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (w13); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_w14.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (w14); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_wp_perm.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (wp_perm); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_wp_pipe.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (wp_pipe); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_wp_script_run.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (wp_script_run); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_wp_script_src.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (wp_script_src); sizinkinde PID, tarih, adres farklı olacaktır |

## Gereksinimler

- bash kabuğu olan bir Linux terminali (laboratuvar bilgisayarları; WSL: PowerShell'de `wsl --install`; ya da Ubuntu sanal makinesi).

## Nasıl kullanılır

Bu hafta ortak alıştırma klasörü `~/lab` içinde çalışılır. Önce klasörü oluşturun (ya da sıfırlayın); tekrar çalıştırmak güvenlidir, yalnızca `~/lab` yeniden oluşturulur:

```bash
bash mcmp117_lab_setup.sh
cd ~/lab
```

`demo_*.sh` dosyaları derste gösterilen komutların aynısını içerir. En iyisi: komutları `~/lab` içinde tek tek kendiniz yazın ve aynı adlı `out_*.txt` ile karşılaştırın. `#!/bin/bash` ile başlayan dosyalar bütün olarak da çalıştırılabilir: `cd ~/lab && bash /yol/demo_adi.sh`. Her dosyanın ilk satırlarındaki yönergeleri okuyun.

`out_*.txt` dosyaları slaytlarda gösterilen gerçek çıktılardır. PID, tarih, saat, boyut, adres ve kullanıcı adları sizin makinenizde farklı olacaktır; çıktılar `LC_ALL=C.UTF-8` ile alınmıştır (Türkçe yerel ayarlı bir sistemde mesajlar Türkçe çıkabilir ve sıralama farklı olabilir). Program çıktıları İngilizcedir.

## Bu haftaya özel notlar

Alıştırma finalinin cevapları `answers_practice.sh` ve `out_pf_*.txt` dosyalarındadır; önce çalışma rehberindeki alıştırma finalini kendiniz çözün.

## Windows kullananlar için

Paketi Linux içinde açın ya da Linux ev dizininize kopyalayın (WSL: `cp -r /mnt/c/Users/<siz>/Downloads/<klasör> ~/`). Bir betik `bad interpreter` ya da `required file not found` hatası verirse Windows satır sonlarıyla kaydedilmiştir; düzeltmek için: `sed -i 's/\r$//' *.sh`. Betikleri `./ad.sh` biçiminde çalıştırmak için `chmod +x *.sh`.

## Bu haftanın slaytları ve notları

Aynı hafta klasöründeki `MBLP131_Hafta15.pptx` / `.pdf` ve `notes/MBLP131_Hafta15_Notlar.pdf`.

---
MBLP131 için hazırlanmıştır — İstanbul Okan Üniversitesi, Meslek Yüksekokulu, 2026. Ders amaçlı kullanım içindir.
