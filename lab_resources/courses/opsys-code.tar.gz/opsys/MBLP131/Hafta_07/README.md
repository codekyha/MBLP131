# MBLP131 — Hafta 7: Sanal Bellek ve Dosya Sistemleri

**Kod paketi** · MBLP131 — İşletim Sistemleri Temelleri  
Dr. Öğr. Üyesi Hasan Oğuz

## İçindekiler

| Dosya | Açıklama (dosyanın başındaki yorumdan) |
|---|---|
| `Makefile` | tüm C programlarını derler: `make` (temizlemek için: `make clean`) |
| `cow_fork.c` | fork() sonrasında yazınca kopyala (3. haftayla bağlantılı). |
| `file_access.c` | sıralı ve doğrudan (göreli) erişim. |
| `page_faults.c` | isteğe bağlı sayfalamayı izleyin. |
| `page_replacement.py` | FIFO, OPT ve LRU sayfa değiştirme benzetimi. |
| `links_demo.sh` | düğümler (inode), sabit bağlantılar ve sembolik bağlantılar. |
| `out_cow_fork.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (cow_fork); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_file_access.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (file_access); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_file_cmd.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (file_cmd); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_links.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (links); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_page_faults.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (page_faults); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_page_replacement.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (page_replacement); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_time_v.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (time_v); sizinkinde PID, tarih, adres farklı olacaktır |

## Gereksinimler

- `gcc` ve `make` kurulu bir Linux sistemi (laboratuvar bilgisayarları, Windows 10/11'de WSL ya da Ubuntu sanal makinesi). Ubuntu'da: `sudo apt install build-essential`.
- `.py` dosyaları için Python 3 (Ubuntu/WSL'de hazır gelir): `python3 dosya.py`.

## Nasıl kullanılır

Tüm C programlarını tek seferde derleyin:

```bash
make
```

Ya da tek tek (her dosyanın başındaki bilgiye göre):

```bash
gcc -Wall -O2 cow_fork.c -o cow_fork
gcc -Wall -O2 file_access.c -o file_access
gcc -Wall -O2 page_faults.c -o page_faults
./page_faults        ya da   /usr/bin/time -v ./page_faults
```

`out_*.txt` dosyaları slaytlarda gösterilen gerçek çıktılardır. PID, tarih, saat, boyut, adres ve kullanıcı adları sizin makinenizde farklı olacaktır; çıktılar `LC_ALL=C.UTF-8` ile alınmıştır (Türkçe yerel ayarlı bir sistemde mesajlar Türkçe çıkabilir ve sıralama farklı olabilir). Program çıktıları İngilizcedir.

## Bu haftaya özel notlar

`links_demo.sh` dosyaları yalnızca kendi geçici klasöründe oluşturup siler.

## Windows kullananlar için

Paketi Linux içinde açın ya da Linux ev dizininize kopyalayın (WSL: `cp -r /mnt/c/Users/<siz>/Downloads/<klasör> ~/`). Bir betik `bad interpreter` ya da `required file not found` hatası verirse Windows satır sonlarıyla kaydedilmiştir; düzeltmek için: `sed -i 's/\r$//' *.sh`. Betikleri `./ad.sh` biçiminde çalıştırmak için `chmod +x *.sh`.

## Bu haftanın slaytları ve notları

Aynı hafta klasöründeki `MBLP131_Hafta7.pptx` / `.pdf` ve `notes/MBLP131_Hafta7_Notlar.pdf`.

---
MBLP131 için hazırlanmıştır — İstanbul Okan Üniversitesi, Meslek Yüksekokulu, 2026. Ders amaçlı kullanım içindir.
