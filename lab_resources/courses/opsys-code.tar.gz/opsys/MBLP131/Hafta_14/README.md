# MBLP131 — Hafta 14: Kabuk Betiklerine Giriş

**Kod paketi** · MBLP131 — İşletim Sistemleri Temelleri  
Dr. Öğr. Üyesi Hasan Oğuz

## İçindekiler

| Dosya | Açıklama (dosyanın başındaki yorumdan) |
|---|---|
| `mcmp117_lab_setup.sh` | ~/lab alıştırma klasörünü oluşturur (bir kez çalıştırın: `bash mcmp117_lab_setup.sh`) |
| `args.sh` | positional parameters: the words typed after the script name echo "Script name  \$0 = $0 echo "First arg    \$1 = $1 echo "Second arg   \$2 = $2 |
| `backup.sh` | timestamped .tar.gz backup of ~/lab/docs into ~/lab/backup |
| `check.sh` | file tests ([ -f ], [ -d ], [ -e ]) and exit statuses if [ $# -ne 1 ]; then                  # exactly one argument? |
| `demo_args.sh` | Week 14 demo 3: positional parameters and read setup: chmod +x *.sh ./args.sh apple "green tea" 42 ./args.sh |
| `demo_backup.sh` | Week 14 demo 7: the complete backup script setup: chmod +x *.sh ./backup.sh ls -l ../backup |
| `demo_errors.sh` | Week 14 demo 9: the most common scripting mistakes The #setup lines create five broken scripts (run them by hand to rebuild them). |
| `demo_first.sh` | Week 14 demo 1: writing and running a first script Type these commands in ~/lab/scripts (after: bash ~/mcmp117_lab_setup.sh and copying the week's example scripts into ~/lab/scripts). |
| `demo_grade.sh` | Week 14 demo 5: if / elif / else and debugging with bash -x setup: chmod +x *.sh ./grade.sh 92 ./grade.sh 72 |
| `demo_loops.sh` | Week 14 demo 6: for and while loops, functions setup: chmod +x *.sh ./loops.sh ./while.sh |
| `demo_report.sh` | Week 14 demo 8: the complete report script setup: chmod +x *.sh ./report.sh |
| `demo_status.sh` | Week 14 demo 4: exit status, test / [ ], file tests setup: chmod +x *.sh ls ../docs > /dev/null echo $? |
| `demo_variables.sh` | Week 14 demo 2: variables, quoting, $( ) and $(( )) |
| `functions.sh` | define a block of commands once, call it many times line() {                                  # no arguments echo "------------------------------------ } |
| `grade.sh` | numeric tests with if / elif / else |
| `greet.sh` | reading input from the keyboard with read read -r -p "What is your name? " name read -r -p "Which year were you born? " year age=$(( $(date +%Y) - year )) |
| `hello.sh` | my first shell script |
| `loops.sh` | three kinds of for loop for city in Istanbul Ankara Izmir; do       # 1) over a list of words echo "City: $city done |
| `quotes.sh` | double quotes, single quotes, backslash, no quotes name="Ayse file="final report.txt"         # a file name that contains a space shellcheck disable=SC2016     # (on purpose) |
| `report.sh` | one-page summary of logs/access.log and data/students.csv log="$HOME/lab/logs/access.log csv="$HOME/lab/data/students.csv for f in "$log" "$csv"; do |
| `variables.sh` | variables, command substitution and arithmetic name="Ayse"                     # NO spaces around the = sign course=MCMP117 week=14 |
| `while.sh` | a counting loop, and a file read line by line n=3 while [ "$n" -gt 0 ]; do                     # repeat WHILE the test is true echo "Countdown: $n |
| `out_args.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (args); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_backup.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (backup); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_errors.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (errors); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_first.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (first); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_grade.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (grade); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_loops.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (loops); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_report.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (report); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_status.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (status); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_variables.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (variables); sizinkinde PID, tarih, adres farklı olacaktır |

## Gereksinimler

- bash kabuğu olan bir Linux terminali (laboratuvar bilgisayarları; WSL: PowerShell'de `wsl --install`; ya da Ubuntu sanal makinesi).

## Nasıl kullanılır

Bu hafta ortak alıştırma klasörü `~/lab` içinde çalışılır. Önce klasörü oluşturun (ya da sıfırlayın); tekrar çalıştırmak güvenlidir, yalnızca `~/lab` yeniden oluşturulur:

```bash
bash mcmp117_lab_setup.sh
cd ~/lab
```

`demo_*.sh` dosyaları derste gösterilen komutların aynısını içerir. En iyisi: komutları `~/lab` içinde tek tek kendiniz yazın ve aynı adlı `out_*.txt` ile karşılaştırın. `#!/bin/bash` ile başlayan dosyalar bütün olarak da çalıştırılabilir: `cd ~/lab && bash /yol/demo_adi.sh`. Her dosyanın ilk satırlarındaki yönergeleri okuyun.

`out_*.txt` dosyaları slaytlarda gösterilen gerçek çıktılardır. PID, tarih, saat, boyut, adres ve kullanıcı adları sizin makinenizde farklı olacaktır; çıktılar `LC_ALL=C.UTF-8` ile alınmıştır (Türkçe yerel ayarlı bir sistemde mesajlar Türkçe çıkabilir ve sıralama farklı olabilir). Program çıktıları İngilizcedir.

## Bu haftaya özel notlar

Örnek betikleri `~/lab/scripts` içine kopyalayın, sonra `chmod +x *.sh`. Çalıştırmadan sözdizimi denetimi: `bash -n betik.sh`; adım adım izleme: `bash -x betik.sh`.

## Windows kullananlar için

Paketi Linux içinde açın ya da Linux ev dizininize kopyalayın (WSL: `cp -r /mnt/c/Users/<siz>/Downloads/<klasör> ~/`). Bir betik `bad interpreter` ya da `required file not found` hatası verirse Windows satır sonlarıyla kaydedilmiştir; düzeltmek için: `sed -i 's/\r$//' *.sh`. Betikleri `./ad.sh` biçiminde çalıştırmak için `chmod +x *.sh`.

## Bu haftanın slaytları ve notları

Aynı hafta klasöründeki `MBLP131_Hafta14.pptx` / `.pdf` ve `notes/MBLP131_Hafta14_Notlar.pdf`.

---
MBLP131 için hazırlanmıştır — İstanbul Okan Üniversitesi, Meslek Yüksekokulu, 2026. Ders amaçlı kullanım içindir.
