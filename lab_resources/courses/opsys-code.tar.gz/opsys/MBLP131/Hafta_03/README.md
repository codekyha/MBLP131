# MBLP131 — Hafta 3: İşletim Sistemi Hizmetleri, Sistem Çağrıları ve Süreçler

**Kod paketi** · MBLP131 — İşletim Sistemleri Temelleri  
Dr. Öğr. Üyesi Hasan Oğuz

## İçindekiler

| Dosya | Açıklama (dosyanın başındaki yorumdan) |
|---|---|
| `Makefile` | tüm C programlarını derler: `make` (temizlemek için: `make clean`) |
| `fork_count.c` | n kez fork() çağrısı kaç süreç yaratır? |
| `fork_exec_wait.c` | kabuktan çalıştırdığınız her programı yaratan üç sistem çağrısı: fork(), exec(), wait(). |
| `mem_layout.c` | bir sürecin parçaları bellekte nerede durur? |
| `raw_write.c` | tek mesaj, üç düzey: kütüphane, sarmalayıcı, çıplak tuzak. |

## Gereksinimler

- `gcc` ve `make` kurulu bir Linux sistemi (laboratuvar bilgisayarları, Windows 10/11'de WSL ya da Ubuntu sanal makinesi). Ubuntu'da: `sudo apt install build-essential`.

## Nasıl kullanılır

Tüm C programlarını tek seferde derleyin:

```bash
make
```

Ya da tek tek (her dosyanın başındaki bilgiye göre):

```bash
gcc -Wall -O2 fork_count.c -o fork_count
./fork_count 3            (her süreç bir satır yazar)
gcc -Wall -O2 fork_exec_wait.c -o fork_exec_wait
./fork_exec_wait
gcc -Wall -O2 mem_layout.c -o mem_layout
./mem_layout
gcc -Wall -O2 raw_write.c -o raw_write
strace ./raw_write
```

## Bu haftaya özel notlar

`raw_write.c` x86-64 Linux sistem çağrısı numaralarını kullanır; ARM makinelerde (bazı dizüstüler, Raspberry Pi) derlenmez. `fork_count` bilerek çok sayıda süreç oluşturur; n değerini küçük tutun.

## Windows kullananlar için

Paketi Linux içinde açın ya da Linux ev dizininize kopyalayın (WSL: `cp -r /mnt/c/Users/<siz>/Downloads/<klasör> ~/`). Bir betik `bad interpreter` ya da `required file not found` hatası verirse Windows satır sonlarıyla kaydedilmiştir; düzeltmek için: `sed -i 's/\r$//' *.sh`. Betikleri `./ad.sh` biçiminde çalıştırmak için `chmod +x *.sh`.

## Bu haftanın slaytları ve notları

Aynı hafta klasöründeki `MBLP131_Hafta3.pptx` / `.pdf` ve `notes/MBLP131_Hafta3_Notlar.pdf`.

---
MBLP131 için hazırlanmıştır — İstanbul Okan Üniversitesi, Meslek Yüksekokulu, 2026. Ders amaçlı kullanım içindir.
