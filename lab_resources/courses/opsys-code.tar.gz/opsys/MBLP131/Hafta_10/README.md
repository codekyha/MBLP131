# MBLP131 — Hafta 10: Dosya ve Dizin İşlemleri

**Kod paketi** · MBLP131 — İşletim Sistemleri Temelleri  
Dr. Öğr. Üyesi Hasan Oğuz

## İçindekiler

| Dosya | Açıklama (dosyanın başındaki yorumdan) |
|---|---|
| `Makefile` | tüm C programlarını derler: `make` (temizlemek için: `make clean`) |
| `mcmp117_lab_setup.sh` | ~/lab alıştırma klasörünü oluşturur (bir kez çalıştırın: `bash mcmp117_lab_setup.sh`) |
| `fileops.c` | Week 10: the system calls behind mkdir, touch, ln, ln -s, mv, rm, rmdir. |
| `demo_cp_mv.sh` | Week 10: copying, moving and renaming. |
| `demo_fileops.sh` | Week 10: compile and run fileops.c (the system calls behind the commands). |
| `demo_links.sh` | Week 10: hard and symbolic links, cp vs mv vs ln (recap of Week 7). |
| `demo_mkdir_touch.sh` | Week 10: creating directories and files, timestamps. |
| `demo_quoting.sh` | Week 10: file names that contain spaces. |
| `demo_rm.sh` | Week 10: deleting files and directories. There is NO recycle bin! |
| `demo_stat_du_df.sh` | Week 10: metadata (stat, link to Week 7 inodes) and disk usage. |
| `demo_strace.sh` | Week 10: which system call does each command use? (link to Weeks 2, 3 and 7) |
| `demo_view.sh` | Week 10: looking inside files: cat, head, tail, wc, file. |
| `demo_wildcards.sh` | Week 10: wildcards (globbing) and brace expansion. |
| `out_cp_mv.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (cp_mv); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_fileops.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (fileops); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_links.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (links); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_mkdir_touch.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (mkdir_touch); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_quoting.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (quoting); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_rm.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (rm); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_stat_du_df.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (stat_du_df); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_strace.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (strace); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_view.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (view); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_wildcards.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (wildcards); sizinkinde PID, tarih, adres farklı olacaktır |

## Gereksinimler

- `gcc` ve `make` kurulu bir Linux sistemi (laboratuvar bilgisayarları, Windows 10/11'de WSL ya da Ubuntu sanal makinesi). Ubuntu'da: `sudo apt install build-essential`.
- bash kabuğu olan bir Linux terminali (laboratuvar bilgisayarları; WSL: PowerShell'de `wsl --install`; ya da Ubuntu sanal makinesi).

## Nasıl kullanılır

Bu hafta ortak alıştırma klasörü `~/lab` içinde çalışılır. Önce klasörü oluşturun (ya da sıfırlayın); tekrar çalıştırmak güvenlidir, yalnızca `~/lab` yeniden oluşturulur:

```bash
bash mcmp117_lab_setup.sh
cd ~/lab
```

`demo_*.sh` dosyaları derste gösterilen komutların aynısını içerir. En iyisi: komutları `~/lab` içinde tek tek kendiniz yazın ve aynı adlı `out_*.txt` ile karşılaştırın. `#!/bin/bash` ile başlayan dosyalar bütün olarak da çalıştırılabilir: `cd ~/lab && bash /yol/demo_adi.sh`. Her dosyanın ilk satırlarındaki yönergeleri okuyun.

Tüm C programlarını tek seferde derleyin:

```bash
make
```

Ya da tek tek (her dosyanın başındaki bilgiye göre):

```bash
gcc -Wall -O2 fileops.c -o fileops      Run it inside ~/lab:  ./fileops
```

`out_*.txt` dosyaları slaytlarda gösterilen gerçek çıktılardır. PID, tarih, saat, boyut, adres ve kullanıcı adları sizin makinenizde farklı olacaktır; çıktılar `LC_ALL=C.UTF-8` ile alınmıştır (Türkçe yerel ayarlı bir sistemde mesajlar Türkçe çıkabilir ve sıralama farklı olabilir). Program çıktıları İngilizcedir.

## Bu haftaya özel notlar

`rm` komutunun geri dönüşüm kutusu yoktur: yalnızca `~/lab` içinde çalışın (kurulum betiğiyle her zaman yeniden oluşturabilirsiniz).

## Windows kullananlar için

Paketi Linux içinde açın ya da Linux ev dizininize kopyalayın (WSL: `cp -r /mnt/c/Users/<siz>/Downloads/<klasör> ~/`). Bir betik `bad interpreter` ya da `required file not found` hatası verirse Windows satır sonlarıyla kaydedilmiştir; düzeltmek için: `sed -i 's/\r$//' *.sh`. Betikleri `./ad.sh` biçiminde çalıştırmak için `chmod +x *.sh`.

## Bu haftanın slaytları ve notları

Aynı hafta klasöründeki `MBLP131_Hafta10.pptx` / `.pdf` ve `notes/MBLP131_Hafta10_Notlar.pdf`.

---
MBLP131 için hazırlanmıştır — İstanbul Okan Üniversitesi, Meslek Yüksekokulu, 2026. Ders amaçlı kullanım içindir.
