# MBLP131 — Hafta 8: Ara Sınav Tekrarı ve Alıştırma

**Kod paketi** · MBLP131 — İşletim Sistemleri Temelleri  
Dr. Öğr. Üyesi Hasan Oğuz

## İçindekiler

| Dosya | Açıklama (dosyanın başındaki yorumdan) |
|---|---|
| `osim.py` | small simulators shared by the Week 8 check scripts. |
| `practice_exam.py` | checks every number in the Practice Exam of the Week 8 Study Guide (notes, Sections "Practice Exam" and "Worked Solutions"). |
| `review_problems.py` | checks every number in the Week 8 slides and in the worked examples / typical questions of the Study Guide (notes, Sections 2-8). |
| `review_results.json` | denetim betiğinin hesapladığı sonuçlar (slaytlarda kullanılır) |
| `out_practice.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (practice); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_review.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (review); sizinkinde PID, tarih, adres farklı olacaktır |

## Gereksinimler

- `gcc` ve `make` kurulu bir Linux sistemi (laboratuvar bilgisayarları, Windows 10/11'de WSL ya da Ubuntu sanal makinesi). Ubuntu'da: `sudo apt install build-essential`.
- `.py` dosyaları için Python 3 (Ubuntu/WSL'de hazır gelir): `python3 dosya.py`.

## Nasıl kullanılır

`out_*.txt` dosyaları slaytlarda gösterilen gerçek çıktılardır. PID, tarih, saat, boyut, adres ve kullanıcı adları sizin makinenizde farklı olacaktır; çıktılar `LC_ALL=C.UTF-8` ile alınmıştır (Türkçe yerel ayarlı bir sistemde mesajlar Türkçe çıkabilir ve sıralama farklı olabilir). Program çıktıları İngilizcedir.

## Bu haftaya özel notlar

Python denetim betikleri tekrar slaytlarındaki ve çalışma rehberindeki alıştırma sınavındaki her sayıyı yeniden üretir: `python3 review_problems.py`, `python3 practice_exam.py`.

## Windows kullananlar için

Paketi Linux içinde açın ya da Linux ev dizininize kopyalayın (WSL: `cp -r /mnt/c/Users/<siz>/Downloads/<klasör> ~/`). Bir betik `bad interpreter` ya da `required file not found` hatası verirse Windows satır sonlarıyla kaydedilmiştir; düzeltmek için: `sed -i 's/\r$//' *.sh`. Betikleri `./ad.sh` biçiminde çalıştırmak için `chmod +x *.sh`.

## Bu haftanın slaytları ve notları

Aynı hafta klasöründeki `MBLP131_Hafta8.pptx` / `.pdf` ve `notes/MBLP131_Hafta8_Notlar.pdf`.

---
MBLP131 için hazırlanmıştır — İstanbul Okan Üniversitesi, Meslek Yüksekokulu, 2026. Ders amaçlı kullanım içindir.
