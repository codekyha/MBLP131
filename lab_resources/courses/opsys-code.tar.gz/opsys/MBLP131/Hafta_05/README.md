# MBLP131 — Hafta 5: CPU Zamanlama Algoritmaları ve Süreç Eşzamanlaması

**Kod paketi** · MBLP131 — İşletim Sistemleri Temelleri  
Dr. Öğr. Üyesi Hasan Oğuz

## İçindekiler

| Dosya | Açıklama (dosyanın başındaki yorumdan) |
|---|---|
| `Makefile` | tüm C programlarını derler: `make` (temizlemek için: `make clean`) |
| `cpu_hog.c` | yalnızca işlemci zamanı yakan bir program (saf "CPU patlaması"). |
| `prodcons.c` | POSIX semaforlarıyla sınırlı tampon üretici-tüketici. |
| `race.c` | iki iş parçacığı TEK bir ortak sayacı KİLİTSİZ artırır. |
| `race_fixed.c` | aynı program; ama artırma işlemi, bir muteks kilidiyle korunan bir KRİTİK BÖLGEdir. |
| `sched_check.py` | a tiny CPU-scheduling simulator for Week 5. |
| `sched_results.json` | denetim betiğinin hesapladığı sonuçlar (slaytlarda kullanılır) |
| `nice_output.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (nice_output); sizinkinde PID, tarih, adres farklı olacaktır |
| `run_output.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (run_output); sizinkinde PID, tarih, adres farklı olacaktır |

## Gereksinimler

- `gcc` ve `make` kurulu bir Linux sistemi (laboratuvar bilgisayarları, Windows 10/11'de WSL ya da Ubuntu sanal makinesi). Ubuntu'da: `sudo apt install build-essential`.
- `.py` dosyaları için Python 3 (Ubuntu/WSL'de hazır gelir): `python3 dosya.py`.

## Nasıl kullanılır

Tüm C programlarını tek seferde derleyin:

```bash
make
```

Ya da tek tek (her dosyanın başındaki bilgiye göre):

```bash
gcc -Wall -O2 cpu_hog.c -o cpu_hog
gcc -Wall -O2 -pthread prodcons.c -o prodcons
./prodcons
gcc -Wall -O2 -pthread race.c -o race
./race
gcc -Wall -O2 -pthread race_fixed.c -o race_fixed
./race_fixed
```

`out_*.txt` dosyaları slaytlarda gösterilen gerçek çıktılardır. PID, tarih, saat, boyut, adres ve kullanıcı adları sizin makinenizde farklı olacaktır; çıktılar `LC_ALL=C.UTF-8` ile alınmıştır (Türkçe yerel ayarlı bir sistemde mesajlar Türkçe çıkabilir ve sıralama farklı olabilir). Program çıktıları İngilizcedir.

## Bu haftaya özel notlar

`race` her çalıştırmada farklı (yanlış) sonuç verir; amaç da budur. `cpu_hog` siz durdurana kadar çalışır: `pkill cpu_hog`.

## Windows kullananlar için

Paketi Linux içinde açın ya da Linux ev dizininize kopyalayın (WSL: `cp -r /mnt/c/Users/<siz>/Downloads/<klasör> ~/`). Bir betik `bad interpreter` ya da `required file not found` hatası verirse Windows satır sonlarıyla kaydedilmiştir; düzeltmek için: `sed -i 's/\r$//' *.sh`. Betikleri `./ad.sh` biçiminde çalıştırmak için `chmod +x *.sh`.

## Bu haftanın slaytları ve notları

Aynı hafta klasöründeki `MBLP131_Hafta5.pptx` / `.pdf` ve `notes/MBLP131_Hafta5_Notlar.pdf`.

---
MBLP131 için hazırlanmıştır — İstanbul Okan Üniversitesi, Meslek Yüksekokulu, 2026. Ders amaçlı kullanım içindir.
