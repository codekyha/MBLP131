# MBLP131 — Hafta 13: Süreçler ve İş Denetimi

**Kod paketi** · MBLP131 — İşletim Sistemleri Temelleri  
Dr. Öğr. Üyesi Hasan Oğuz

## İçindekiler

| Dosya | Açıklama (dosyanın başındaki yorumdan) |
|---|---|
| `Makefile` | tüm C programlarını derler: `make` (temizlemek için: `make clean`) |
| `mcmp117_lab_setup.sh` | ~/lab alıştırma klasörünü oluşturur (bir kez çalıştırın: `bash mcmp117_lab_setup.sh`) |
| `catch.c` | a process that handles some signals itself. |
| `zombie.c` | make a zombie process on purpose (links to Week 3). |
| `check_numbers.py` | verifies every number quoted on the Week 13 slides/notes. |
| `demo_catch.sh` | Week 13: a program that catches SIGINT and SIGTERM. |
| `demo_jobs.sh` | Week 13: foreground, background and job control. |
| `demo_nice.sh` | Week 13: nice and renice (links to Week 5 priority scheduling). |
| `demo_nohup.sh` | Week 13: $$, $!, SIGHUP and nohup. |
| `demo_proc.sh` | Week 13: the PCB through /proc (links to Week 3). |
| `demo_ps.sh` | Week 13: looking at processes with ps and pstree. |
| `demo_signals.sh` | Week 13: sending signals with kill, pkill and killall. |
| `demo_top.sh` | Week 13: one snapshot of top (batch mode, -b -n 1). |
| `demo_zombie.sh` | Week 13: seeing process state Z (links to Week 3). |
| `out_catch.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (catch); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_check_numbers.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (check_numbers); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_jobs.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (jobs); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_nice.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (nice); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_nohup.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (nohup); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_proc.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (proc); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_ps.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (ps); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_signals.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (signals); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_top.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (top); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_zombie.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (zombie); sizinkinde PID, tarih, adres farklı olacaktır |

## Gereksinimler

- `gcc` ve `make` kurulu bir Linux sistemi (laboratuvar bilgisayarları, Windows 10/11'de WSL ya da Ubuntu sanal makinesi). Ubuntu'da: `sudo apt install build-essential`.
- bash kabuğu olan bir Linux terminali (laboratuvar bilgisayarları; WSL: PowerShell'de `wsl --install`; ya da Ubuntu sanal makinesi).
- `.py` dosyaları için Python 3 (Ubuntu/WSL'de hazır gelir): `python3 dosya.py`.

## Nasıl kullanılır

Bu hafta ortak alıştırma klasörü `~/lab` içinde çalışılır. Önce klasörü oluşturun (ya da sıfırlayın); tekrar çalıştırmak güvenlidir, yalnızca `~/lab` yeniden oluşturulur:

```bash
bash mcmp117_lab_setup.sh
cd ~/lab
```

`demo_*.sh` dosyaları derste gösterilen komutların aynısını içerir. En iyisi: komutları `~/lab` içinde tek tek kendiniz yazın ve aynı adlı `out_*.txt` ile karşılaştırın. `#!/bin/bash` ile başlayan dosyalar bütün olarak da çalıştırılabilir: `cd ~/lab && bash /yol/demo_adi.sh`. Her dosyanın ilk satırlarındaki yönergeleri okuyun.

Tüm C programlarını tek seferde derleyin:

```bash
make
```

Ya da tek tek (her dosyanın başındaki bilgiye göre):

```bash
gcc -Wall -O2 catch.c -o catch
./catch &    then   kill -INT %1 ; kill %1    (or kill -9 %1)
gcc -Wall -O2 zombie.c -o zombie
./zombie 20 &      then   ps -o pid,ppid,stat,cmd
```

`out_*.txt` dosyaları slaytlarda gösterilen gerçek çıktılardır. PID, tarih, saat, boyut, adres ve kullanıcı adları sizin makinenizde farklı olacaktır; çıktılar `LC_ALL=C.UTF-8` ile alınmıştır (Türkçe yerel ayarlı bir sistemde mesajlar Türkçe çıkabilir ve sıralama farklı olabilir). Program çıktıları İngilizcedir.

## Bu haftaya özel notlar

İş denetimi gösterimleri etkileşimli bir terminalde elle yazılmalıdır; dosyadaki `#@key C-z` "Ctrl+Z'ye basın" demektir. `kill -9` yalnızca son çare olmalıdır. `./zombie` bilerek birkaç saniyeliğine bir zombi süreç bırakır.

## Windows kullananlar için

Paketi Linux içinde açın ya da Linux ev dizininize kopyalayın (WSL: `cp -r /mnt/c/Users/<siz>/Downloads/<klasör> ~/`). Bir betik `bad interpreter` ya da `required file not found` hatası verirse Windows satır sonlarıyla kaydedilmiştir; düzeltmek için: `sed -i 's/\r$//' *.sh`. Betikleri `./ad.sh` biçiminde çalıştırmak için `chmod +x *.sh`.

## Bu haftanın slaytları ve notları

Aynı hafta klasöründeki `MBLP131_Hafta13.pptx` / `.pdf` ve `notes/MBLP131_Hafta13_Notlar.pdf`.

---
MBLP131 için hazırlanmıştır — İstanbul Okan Üniversitesi, Meslek Yüksekokulu, 2026. Ders amaçlı kullanım içindir.
