# MBLP131 — Hafta 11: İzinler, Sahiplik ve Kullanıcılar

**Kod paketi** · MBLP131 — İşletim Sistemleri Temelleri  
Dr. Öğr. Üyesi Hasan Oğuz

## İçindekiler

| Dosya | Açıklama (dosyanın başındaki yorumdan) |
|---|---|
| `mcmp117_lab_setup.sh` | ~/lab alıştırma klasörünü oluşturur (bir kez çalıştırın: `bash mcmp117_lab_setup.sh`) |
| `perm_check.py` | verifies every octal/umask number used in the Week 11 slides and notes. |
| `demo_chmod_oct.sh` | chmod in octal mode: r = 4, w = 2, x = 1 cd docs chmod 754 syllabus.txt ls -l syllabus.txt |
| `demo_chmod_sym.sh` | chmod in symbolic mode: who (u g o a), op (+ - =), perms (r w x) |
| `demo_dirperm.sh` | what r, w and x mean for a DIRECTORY mkdir box echo "top secret" > box/secret.txt ls -ld box |
| `demo_group.sh` | sharing through a group (the administrator has added you to 'students') |
| `demo_ls.sh` | reading the mode string with ls -l, ls -ld and stat (Week 11) |
| `demo_order.sh` | only ONE class applies: the owner gets the owner bits, even if they are worse echo "hello" > me.txt chmod 074 me.txt ls -l me.txt |
| `demo_owner.sh` | chown and chgrp as an ordinary user ls -l docs/notes_01.txt chown root docs/notes_01.txt chgrp students docs/notes_01.txt |
| `demo_script.sh` | making a script (and a compiled program) executable cd scripts echo '#!/bin/bash' > hello.sh echo 'echo "Hello, $USER! You are in $PWD"' >> hello.sh |
| `demo_special.sh` | setuid (passwd) and the sticky bit (/tmp) |
| `demo_sudo.sh` | sudo for a user who IS an administrator (member of group sudo) |
| `demo_sudo_denied.sh` | sudo for a user who is NOT an administrator sudo whoami |
| `demo_umask.sh` | default permissions: new file 666 / new directory 777, minus the umask bits mkdir umask_test cd umask_test umask |
| `demo_users.sh` | who am I? users, groups and the account files (Week 11) |
| `out_chmod_oct.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (chmod_oct); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_chmod_sym.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (chmod_sym); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_dirperm.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (dirperm); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_group.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (group); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_ls.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (ls); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_order.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (order); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_owner.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (owner); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_perm_check.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (perm_check); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_script.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (script); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_special.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (special); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_sudo.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (sudo); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_sudo_denied.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (sudo_denied); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_umask.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (umask); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_users.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (users); sizinkinde PID, tarih, adres farklı olacaktır |

## Gereksinimler

- bash kabuğu olan bir Linux terminali (laboratuvar bilgisayarları; WSL: PowerShell'de `wsl --install`; ya da Ubuntu sanal makinesi).
- `.py` dosyaları için Python 3 (Ubuntu/WSL'de hazır gelir): `python3 dosya.py`.

## Nasıl kullanılır

Bu hafta ortak alıştırma klasörü `~/lab` içinde çalışılır. Önce klasörü oluşturun (ya da sıfırlayın); tekrar çalıştırmak güvenlidir, yalnızca `~/lab` yeniden oluşturulur:

```bash
bash mcmp117_lab_setup.sh
cd ~/lab
```

`demo_*.sh` dosyaları derste gösterilen komutların aynısını içerir. En iyisi: komutları `~/lab` içinde tek tek kendiniz yazın ve aynı adlı `out_*.txt` ile karşılaştırın. `#!/bin/bash` ile başlayan dosyalar bütün olarak da çalıştırılabilir: `cd ~/lab && bash /yol/demo_adi.sh`. Her dosyanın ilk satırlarındaki yönergeleri okuyun.

`out_*.txt` dosyaları slaytlarda gösterilen gerçek çıktılardır. PID, tarih, saat, boyut, adres ve kullanıcı adları sizin makinenizde farklı olacaktır; çıktılar `LC_ALL=C.UTF-8` ile alınmıştır (Türkçe yerel ayarlı bir sistemde mesajlar Türkçe çıkabilir ve sıralama farklı olabilir). Program çıktıları İngilizcedir.

## Bu haftaya özel notlar

`demo_sudo.sh` sudo kullanma yetkisi olan bir hesap ister; laboratuvar bilgisayarlarında bu yetkiniz olmayabilir, çıktı dosyasını okumanız yeterli. Bir sorunu "çözmek" için asla `chmod 777` kullanmayın.

## Windows kullananlar için

Paketi Linux içinde açın ya da Linux ev dizininize kopyalayın (WSL: `cp -r /mnt/c/Users/<siz>/Downloads/<klasör> ~/`). Bir betik `bad interpreter` ya da `required file not found` hatası verirse Windows satır sonlarıyla kaydedilmiştir; düzeltmek için: `sed -i 's/\r$//' *.sh`. Betikleri `./ad.sh` biçiminde çalıştırmak için `chmod +x *.sh`.

## Bu haftanın slaytları ve notları

Aynı hafta klasöründeki `MBLP131_Hafta11.pptx` / `.pdf` ve `notes/MBLP131_Hafta11_Notlar.pdf`.

---
MBLP131 için hazırlanmıştır — İstanbul Okan Üniversitesi, Meslek Yüksekokulu, 2026. Ders amaçlı kullanım içindir.
