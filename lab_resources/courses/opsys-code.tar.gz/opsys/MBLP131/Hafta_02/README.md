# MBLP131 — Hafta 2: Tanımlar, Hedefler, Bileşenler ve İşletim Sistemi Yapıları

**Kod paketi** · MBLP131 — İşletim Sistemleri Temelleri  
Dr. Öğr. Üyesi Hasan Oğuz

## İçindekiler

| Dosya | Açıklama (dosyanın başındaki yorumdan) |
|---|---|
| `Kbuild` | çekirdek modülü derleme tanımı (`make module` kullanır) |
| `Makefile` | tüm C programlarını derler: `make` (temizlemek için: `make clean`) |
| `hello_module.c` | en küçük Linux yüklenebilir çekirdek modülü (LKM). |
| `hello_syscall.c` | aynı mesaj, iki yolla yazdırılır. |
| `syscall_cost.c` | çekirdeğe bir gidiş-dönüş ne kadar pahalı? |

## Gereksinimler

- `gcc` ve `make` kurulu bir Linux sistemi (laboratuvar bilgisayarları, Windows 10/11'de WSL ya da Ubuntu sanal makinesi). Ubuntu'da: `sudo apt install build-essential`.

## Nasıl kullanılır

Tüm C programlarını tek seferde derleyin:

```bash
make
```

Ya da tek tek (her dosyanın başındaki bilgiye göre):

```bash
make                  (çekirdek başlık paketi gerekir)
sudo insmod hello_module.ko
sudo rmmod hello_module
gcc hello_syscall.c -o hello_syscall
./hello_syscall
strace ./hello_syscall     (yalnızca Linux)
gcc -O2 syscall_cost.c -o syscall_cost
./syscall_cost
```

## Bu haftaya özel notlar

`hello_module.c` bir Linux çekirdek modülüdür: `make module` ile derleyin ve YALNIZCA bozulmasında sakınca olmayan bir sanal makinede yükleyin. `syscall_cost` süreleri makineye göre değişir; asıl ders aradaki orandır.

## Windows kullananlar için

Paketi Linux içinde açın ya da Linux ev dizininize kopyalayın (WSL: `cp -r /mnt/c/Users/<siz>/Downloads/<klasör> ~/`). Bir betik `bad interpreter` ya da `required file not found` hatası verirse Windows satır sonlarıyla kaydedilmiştir; düzeltmek için: `sed -i 's/\r$//' *.sh`. Betikleri `./ad.sh` biçiminde çalıştırmak için `chmod +x *.sh`.

## Bu haftanın slaytları ve notları

Aynı hafta klasöründeki `MBLP131_Hafta2.pptx` / `.pdf` ve `notes/MBLP131_Hafta2_Notlar.pdf`.

---
MBLP131 için hazırlanmıştır — İstanbul Okan Üniversitesi, Meslek Yüksekokulu, 2026. Ders amaçlı kullanım içindir.
