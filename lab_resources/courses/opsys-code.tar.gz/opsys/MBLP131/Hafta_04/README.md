# MBLP131 — Hafta 4: İş Parçacıkları ve CPU Zamanlamasının Temelleri

**Kod paketi** · MBLP131 — İşletim Sistemleri Temelleri  
Dr. Öğr. Üyesi Hasan Oğuz

## İçindekiler

| Dosya | Açıklama (dosyanın başındaki yorumdan) |
|---|---|
| `Makefile` | tüm C programlarını derler: `make` (temizlemek için: `make clean`) |
| `array_sum.c` | büyük bir diziyi T iş parçacığıyla toplar. |
| `burst.c` | tek dosyada bir CPU yoğun ve bir G/Ç yoğun program. |
| `create_cost.c` | iş parçacığı gerçekten süreçten ucuz mu? |
| `thread_hello.c` | tek süreç, birkaç iş parçacığı. |

## Gereksinimler

- `gcc` ve `make` kurulu bir Linux sistemi (laboratuvar bilgisayarları, Windows 10/11'de WSL ya da Ubuntu sanal makinesi). Ubuntu'da: `sudo apt install build-essential`.

## Nasıl kullanılır

Tüm C programlarını tek seferde derleyin:

```bash
make
```

Ya da tek tek (her dosyanın başındaki bilgiye göre):

```bash
gcc -Wall -O2 -pthread array_sum.c -o array_sum
./array_sum 1     ./array_sum 2     ./array_sum 4
gcc -Wall -O2 burst.c -o burst
gcc -Wall -O2 -pthread create_cost.c -o create_cost
./create_cost
gcc -Wall -O2 -pthread thread_hello.c -o thread_hello
./thread_hello
```

## Bu haftaya özel notlar

İş parçacığı programları `-pthread` ister (Makefile ekler). Süreler makineden makineye değişir.

## Windows kullananlar için

Paketi Linux içinde açın ya da Linux ev dizininize kopyalayın (WSL: `cp -r /mnt/c/Users/<siz>/Downloads/<klasör> ~/`). Bir betik `bad interpreter` ya da `required file not found` hatası verirse Windows satır sonlarıyla kaydedilmiştir; düzeltmek için: `sed -i 's/\r$//' *.sh`. Betikleri `./ad.sh` biçiminde çalıştırmak için `chmod +x *.sh`.

## Bu haftanın slaytları ve notları

Aynı hafta klasöründeki `MBLP131_Hafta4.pptx` / `.pdf` ve `notes/MBLP131_Hafta4_Notlar.pdf`.

---
MBLP131 için hazırlanmıştır — İstanbul Okan Üniversitesi, Meslek Yüksekokulu, 2026. Ders amaçlı kullanım içindir.
