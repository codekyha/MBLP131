# MBLP131 — Hafta 12: Metin İşleme, Yönlendirme ve Boru Hatları

**Kod paketi** · MBLP131 — İşletim Sistemleri Temelleri  
Dr. Öğr. Üyesi Hasan Oğuz

## İçindekiler

| Dosya | Açıklama (dosyanın başındaki yorumdan) |
|---|---|
| `mcmp117_lab_setup.sh` | ~/lab alıştırma klasörünü oluşturur (bir kez çalıştırın: `bash mcmp117_lab_setup.sh`) |
| `demo_analysis.sh` | MCMP117 Week 12: real analyses of logs/access.log, logs/system.log and data/students.csv |
| `demo_cut_tr_wc.sh` | MCMP117 Week 12: cut, tr and wc |
| `demo_find_xargs.sh` | MCMP117 Week 12: find, -exec and xargs |
| `demo_grep.sh` | MCMP117 Week 12: grep: search lines |
| `demo_head_tail_tee.sh` | MCMP117 Week 12: head and tail in pipelines, tee |
| `demo_mistakes.sh` | MCMP117 Week 12: common mistakes, made on purpose |
| `demo_pipes.sh` | MCMP117 Week 12: pipes: processes connected by a pipe |
| `demo_redirect.sh` | MCMP117 Week 12: output, input and error redirection |
| `demo_regex.sh` | MCMP117 Week 12: simple regular expressions with grep |
| `demo_sort_uniq.sh` | MCMP117 Week 12: sort and uniq |
| `demo_strace.sh` | MCMP117 Week 12: what the shell really does: strace shows write(), dup2() and pipe2() |
| `demo_streams.sh` | MCMP117 Week 12: the three standard streams (file descriptors 0, 1, 2) |
| `out_analysis.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (analysis); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_cut_tr_wc.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (cut_tr_wc); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_find_xargs.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (find_xargs); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_grep.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (grep); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_head_tail_tee.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (head_tail_tee); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_mistakes.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (mistakes); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_pipes.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (pipes); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_redirect.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (redirect); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_regex.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (regex); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_sort_uniq.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (sort_uniq); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_strace.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (strace); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_streams.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (streams); sizinkinde PID, tarih, adres farklı olacaktır |

## Gereksinimler

- bash kabuğu olan bir Linux terminali (laboratuvar bilgisayarları; WSL: PowerShell'de `wsl --install`; ya da Ubuntu sanal makinesi).

## Nasıl kullanılır

Bu hafta ortak alıştırma klasörü `~/lab` içinde çalışılır. Önce klasörü oluşturun (ya da sıfırlayın); tekrar çalıştırmak güvenlidir, yalnızca `~/lab` yeniden oluşturulur:

```bash
bash mcmp117_lab_setup.sh
cd ~/lab
```

`demo_*.sh` dosyaları derste gösterilen komutların aynısını içerir. En iyisi: komutları `~/lab` içinde tek tek kendiniz yazın ve aynı adlı `out_*.txt` ile karşılaştırın. `#!/bin/bash` ile başlayan dosyalar bütün olarak da çalıştırılabilir: `cd ~/lab && bash /yol/demo_adi.sh`. Her dosyanın ilk satırlarındaki yönergeleri okuyun.

`out_*.txt` dosyaları slaytlarda gösterilen gerçek çıktılardır. PID, tarih, saat, boyut, adres ve kullanıcı adları sizin makinenizde farklı olacaktır; çıktılar `LC_ALL=C.UTF-8` ile alınmıştır (Türkçe yerel ayarlı bir sistemde mesajlar Türkçe çıkabilir ve sıralama farklı olabilir). Program çıktıları İngilizcedir.

## Bu haftaya özel notlar

Tüm çözümlemeler `~/lab/logs` ve `~/lab/data` dosyalarını okur; önce kurulum betiğini çalıştırın.

## Windows kullananlar için

Paketi Linux içinde açın ya da Linux ev dizininize kopyalayın (WSL: `cp -r /mnt/c/Users/<siz>/Downloads/<klasör> ~/`). Bir betik `bad interpreter` ya da `required file not found` hatası verirse Windows satır sonlarıyla kaydedilmiştir; düzeltmek için: `sed -i 's/\r$//' *.sh`. Betikleri `./ad.sh` biçiminde çalıştırmak için `chmod +x *.sh`.

## Bu haftanın slaytları ve notları

Aynı hafta klasöründeki `MBLP131_Hafta12.pptx` / `.pdf` ve `notes/MBLP131_Hafta12_Notlar.pdf`.

---
MBLP131 için hazırlanmıştır — İstanbul Okan Üniversitesi, Meslek Yüksekokulu, 2026. Ders amaçlı kullanım içindir.
