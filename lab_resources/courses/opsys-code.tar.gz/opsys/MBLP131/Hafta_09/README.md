# MBLP131 — Hafta 9: Linux Kabuğuna Giriş ve Dosya Sisteminde Gezinme

**Kod paketi** · MBLP131 — İşletim Sistemleri Temelleri  
Dr. Öğr. Üyesi Hasan Oğuz

## İçindekiler

| Dosya | Açıklama (dosyanın başındaki yorumdan) |
|---|---|
| `mcmp117_lab_setup.sh` | ~/lab alıştırma klasörünü oluşturur (bir kez çalıştırın: `bash mcmp117_lab_setup.sh`) |
| `check_numbers.py` | Week 9: verifies the numbers quoted on the slides and in the notes. |
| `demo_cd.sh` | Week 9: moving around with cd (absolute and relative paths, ~ . .. -) |
| `demo_errors.sh` | Week 9: common error messages and what they mean cd ~/lab LS sl |
| `demo_fhs.sh` | Week 9: a tour of the Linux directory tree (FHS) |
| `demo_first.sh` | Week 9: first commands Type these lines one by one in a terminal (or run: bash demo_first.sh). |
| `demo_help.sh` | Week 9: getting help (--help, help, type) |
| `demo_keys.sh` | Week 9: tab completion and history TYPE THESE BY HAND: "\t" means "press the Tab key". (History expansion with ! works only when you type commands, not inside a script.) |
| `demo_ls.sh` | Week 9: where am I, and what is here? (pwd, ls and its options) |
| `demo_setup.sh` | Week 9: running the lab setup script (once per computer) |
| `demo_syscalls.sh` | Week 9: commands become system calls (link to Weeks 2 and 3) |
| `demo_tree.sh` | Week 9: looking at a whole subtree (ls -R, tree, ls -d) |
| `out_cd.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (cd); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_check_numbers.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (check_numbers); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_errors.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (errors); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_fhs.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (fhs); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_first.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (first); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_help.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (help); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_keys.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (keys); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_ls.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (ls); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_setup.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (setup); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_syscalls.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (syscalls); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_tree.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (tree); sizinkinde PID, tarih, adres farklı olacaktır |

## Gereksinimler

- bash kabuğu olan bir Linux terminali (laboratuvar bilgisayarları; WSL: PowerShell'de `wsl --install`; ya da Ubuntu sanal makinesi).
- `.py` dosyaları için Python 3 (Ubuntu/WSL'de hazır gelir): `python3 dosya.py`.

## Nasıl kullanılır

Bu hafta ortak alıştırma klasörü `~/lab` içinde çalışılır. Önce klasörü oluşturun (ya da sıfırlayın); tekrar çalıştırmak güvenlidir, yalnızca `~/lab` yeniden oluşturulur:

```bash
bash mcmp117_lab_setup.sh
cd ~/lab
```

`demo_*.sh` dosyaları derste gösterilen komutların aynısını içerir. En iyisi: komutları `~/lab` içinde tek tek kendiniz yazın ve aynı adlı `out_*.txt` ile karşılaştırın. `#!/bin/bash` ile başlayan dosyalar bütün olarak da çalıştırılabilir: `cd ~/lab && bash /yol/demo_adi.sh`. Her dosyanın ilk satırlarındaki yönergeleri okuyun.

`out_*.txt` dosyaları slaytlarda gösterilen gerçek çıktılardır. PID, tarih, saat, boyut, adres ve kullanıcı adları sizin makinenizde farklı olacaktır; çıktılar `LC_ALL=C.UTF-8` ile alınmıştır (Türkçe yerel ayarlı bir sistemde mesajlar Türkçe çıkabilir ve sıralama farklı olabilir). Program çıktıları İngilizcedir.

## Bu haftaya özel notlar

Bu hafta derleme yok. Herhangi bir çözüme bakmadan önce Laboratuvar Föyü alıştırmalarını kendiniz deneyin.

## Windows kullananlar için

Paketi Linux içinde açın ya da Linux ev dizininize kopyalayın (WSL: `cp -r /mnt/c/Users/<siz>/Downloads/<klasör> ~/`). Bir betik `bad interpreter` ya da `required file not found` hatası verirse Windows satır sonlarıyla kaydedilmiştir; düzeltmek için: `sed -i 's/\r$//' *.sh`. Betikleri `./ad.sh` biçiminde çalıştırmak için `chmod +x *.sh`.

## Bu haftanın slaytları ve notları

Aynı hafta klasöründeki `MBLP131_Hafta9.pptx` / `.pdf` ve `notes/MBLP131_Hafta9_Notlar.pdf`.

---
MBLP131 için hazırlanmıştır — İstanbul Okan Üniversitesi, Meslek Yüksekokulu, 2026. Ders amaçlı kullanım içindir.
