# MBLP131 — Hafta 6: Bellek Yönetimi, Sayfalama ve Bölütleme

**Kod paketi** · MBLP131 — İşletim Sistemleri Temelleri  
Dr. Öğr. Üyesi Hasan Oğuz

## İçindekiler

| Dosya | Açıklama (dosyanın başındaki yorumdan) |
|---|---|
| `Makefile` | tüm C programlarını derler: `make` (temizlemek için: `make clean`) |
| `fork_vaddr.c` | same virtual address, different values. |
| `mem_layout.c` | where do code, globals, heap and stack live? |
| `page_split.c` | split an address into page number p and offset d. |
| `fit.py` | first-fit, best-fit and worst-fit on one shared example. |
| `verify.py` | checks every number used in the Week 6 slides and notes. |
| `out_fit.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (fit); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_fork_vaddr.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (fork_vaddr); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_mem_layout.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (mem_layout); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_page_split.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (page_split); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_shell.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (shell); sizinkinde PID, tarih, adres farklı olacaktır |
| `out_verify.txt` | slaytlar/notlar için kaydedilmiş gerçek çıktı (verify); sizinkinde PID, tarih, adres farklı olacaktır |

## Gereksinimler

- `gcc` ve `make` kurulu bir Linux sistemi (laboratuvar bilgisayarları, Windows 10/11'de WSL ya da Ubuntu sanal makinesi). Ubuntu'da: `sudo apt install build-essential`.
- `.py` dosyaları için Python 3 (Ubuntu/WSL'de hazır gelir): `python3 dosya.py`.

## Nasıl kullanılır

Tüm C programlarını tek seferde derleyin:

```bash
make
```

Ya da tek tek (her dosyanın başındaki bilgiye göre):

```bash
gcc -Wall -O2 fork_vaddr.c -o fork_vaddr
gcc -Wall -O2 mem_layout.c -o mem_layout
./mem_layout
gcc -Wall -O2 page_split.c -o page_split
./page_split 0x3A7F 0x1234 0x5000
```

`out_*.txt` dosyaları slaytlarda gösterilen gerçek çıktılardır. PID, tarih, saat, boyut, adres ve kullanıcı adları sizin makinenizde farklı olacaktır; çıktılar `LC_ALL=C.UTF-8` ile alınmıştır (Türkçe yerel ayarlı bir sistemde mesajlar Türkçe çıkabilir ve sıralama farklı olabilir). Program çıktıları İngilizcedir.

## Bu haftaya özel notlar

Adresler her çalıştırmada değişir (adres uzayı rastgeleleştirmesi).

## Windows kullananlar için

Paketi Linux içinde açın ya da Linux ev dizininize kopyalayın (WSL: `cp -r /mnt/c/Users/<siz>/Downloads/<klasör> ~/`). Bir betik `bad interpreter` ya da `required file not found` hatası verirse Windows satır sonlarıyla kaydedilmiştir; düzeltmek için: `sed -i 's/\r$//' *.sh`. Betikleri `./ad.sh` biçiminde çalıştırmak için `chmod +x *.sh`.

## Bu haftanın slaytları ve notları

Aynı hafta klasöründeki `MBLP131_Hafta6.pptx` / `.pdf` ve `notes/MBLP131_Hafta6_Notlar.pdf`.

---
MBLP131 için hazırlanmıştır — İstanbul Okan Üniversitesi, Meslek Yüksekokulu, 2026. Ders amaçlı kullanım içindir.
