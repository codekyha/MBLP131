# Fundamentals of Operating Systems - code base

The programs, scripts and captured outputs of the weekly lectures and labs of **MCMP117 Fundamentals of Operating
Systems** (English) and **MBLP131 İşletim Sistemleri Temelleri** (Turkish), Weeks 2-15. They are the same "code packs"
that are handed out to the students, installed on this lab machine (the VirtualBox VM or Ubuntu Lab on WSL 2).

| Folder | Edition |
|---|---|
| `MCMP117/Week_02` ... `Week_15` | English |
| `MBLP131/Hafta_02` ... `Hafta_15` | Turkish (the same programs; Turkish comments and README files) |

Every week folder has its own `README.md`: the files, the commands, what to look for.

| Week | Topic | What is in the folder |
|---|---|---|
| 2 | Definitions, goals, components, OS structures | C: a system call by hand, the cost of a system call, a kernel module |
| 3 | OS services, system calls, processes | C: `fork`/`exec`/`wait`, memory layout, a raw `write` |
| 4 | Threads, CPU scheduling basics | C: POSIX threads |
| 5 | Scheduling algorithms, synchronization | C: race condition, mutex, producer-consumer; Python: scheduling simulator |
| 6 | Memory management, paging, segmentation | C and Python: address spaces, page split, allocation strategies |
| 7 | Virtual memory, file systems | C: page faults, copy-on-write, file access; Python: page replacement; shell: links |
| 8 | Midterm review | Python: review problems, practice exam, small OS simulator |
| 9-14 | Linux: shell, files, permissions, text processing, processes, scripting | `demo_*.sh` (the commands shown in class) and `out_*.txt` (their captured output) |
| 15 | Final review | shell exercises, helper library and answers |

## Quick start

```bash
cd ~/opsys/MCMP117/Week_03        # or ~/opsys/MBLP131/Hafta_03
make                              # builds the C programs of the week
./fork_exec_wait

cd ~/opsys/MCMP117/Week_05 && python3 sched_check.py

# Linux weeks (9-15): the demos work in the practice folder ~/lab, which the lab installation has created
ls ~/lab
bash ~/opsys/MCMP117/Week_09/mcmp117_lab_setup.sh        # re-creates ~/lab from scratch
cd ~/lab && bash ~/opsys/MCMP117/Week_09/demo_ls.sh
```

Everything the programs need (`gcc`, `make`, `gdb`, `strace`, `tree`, `pstree`, `python3`, ...) is installed on the lab machine.
Read the captured `out_*.txt` files next to the programs: PIDs, addresses, times and sizes on your machine will differ.

## Good to know

* The files are yours: edit, compile, break things. The installation never overwrites a file that exists.
  `bash /opt/lab/courses/opsys_code.sh --reset` puts the original course files back (files you added stay).
* Week 2: the kernel module (`make module`) needs the kernel headers (`linux-headers-$(uname -r)`), which are not installed.
  Try modules only in the VirtualBox VM, never in WSL and never on a computer you cannot afford to crash.
* Week 3: `raw_write.c` uses x86-64 system-call numbers; `fork_count` creates many processes on purpose - keep `n` small.
* The slides and notes of the course are not part of the lab machine, and neither is the instructor material
  (solutions, slide excerpts).

## Türkçe özet

Bu klasör, MBLP131 İşletim Sistemleri Temelleri (Türkçe) ve MCMP117 Fundamentals of Operating Systems (İngilizce)
derslerinin 2-15. haftalarının kodlarını içerir: `MBLP131/Hafta_NN` Türkçe, `MCMP117/Week_NN` İngilizce sürümdür
(aynı programlar). Her hafta klasöründe kendi `README.md` dosyası vardır. Başlamak için:
`cd ~/opsys/MBLP131/Hafta_03 && make`. Dosyalar sizindir; kurulum var olan dosyaların üzerine yazmaz
(`bash /opt/lab/courses/opsys_code.sh --reset` özgün dosyaları geri koyar). Çekirdek modülü (Hafta 2) yalnızca
VirtualBox sanal makinesinde denenmelidir.
